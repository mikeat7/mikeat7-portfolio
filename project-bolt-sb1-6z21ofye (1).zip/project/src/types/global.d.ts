// Global type definitions for Tavus CVI integration

declare global {
  interface Window {
    Daily: any;
    tavusCallFrame: any;
  }
}

export {};